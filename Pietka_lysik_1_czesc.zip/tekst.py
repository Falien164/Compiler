q1 = (str)2000
print q1
q2 = "world "
print q2
print q2 + q1

str1 = "wczytywanie zmiennych:"
print str1
x_i = 0
print x_i
read x_i
print x_i

x_d = 0.0
print x_d
read x_d
print x_d

str2 = "Liczby calkowite:"
print str2
print 5 + 1         #6
print 100 / 20      #5
b= -3 - 2           
print b             #-5
a= 10 + 2       
print a             #12     
print ((a + b) * a) / ((int)2.0 * 2) #21
print a - b         #17
print a * b         #-60
print a / b         #-2

str3 = "Liczby rzeczywiste:"
print str3 
print 3.0 * 3.0     #9.0
print (int)10.0 / 2 #5
e= -3.0+1.0
print e             #-2.0
e= (real)5 * 3.0    
print e             #15.0
d = 10.0 / 2.0      
print d             #5.0
print e * d         #75



str4 = "operacje na zmiennych:"
print str4
print 1 * 2 
x1 = 4
x2=x1
print x2            #4
print x2 * x1       #16 
x3 = x1 * x2
print x3            #16
z = "Bazinga"
print z 
print z 

str5 = "Wyswietlanie tablic:"
print str5
array = {1, 2, 3, 4, 5}
print array[0]
x = array[0]
print x
y = array[0 + 2]
print y
array[0] = 20
print array[0]
i = 3
print array[i]
b = array[i]
print b
c = {4.0, 3.2}
print c[1]

